// configuration
const configuration = {
    UserAgent : 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko)', // Dont Change/Replace This useragent
    userId: 'xxxxxxxxxxxxxxxx',  // Replace with Your User ID HERE
    proxyFile: 'proxy.txt' // your Path to Proxy.txt file
    // format proxies is => socks://username:pass@ip:port or http://username:pass@ip:port
};

module.exports = configuration;