const pino = require('pino');
const logger = pino({ level: 'info', transport: { target: 'pino-pretty' } });
const WebSocket = require('ws');
const axios = require('axios');
const { v4: uuidv4 } = require('uuid');
const { SocksProxyAgent } = require('socks-proxy-agent');
const { HttpsProxyAgent } = require('https-proxy-agent');
const fs = require('fs');
const readline = require('readline');
const configuration = require('./configuration');

let CoderMarkPrinted = false;

const cl = {
    gr: '\x1b[32m',
    br: '\x1b[34m',
    red: '\x1b[31m',
    yl: '\x1b[33m',
    gb: '\x1b[4m',
    rt: '\x1b[0m'
};

class Config {
    constructor() {
        this.ipCheckURL = 'https://ipinfo.io/json';
        this.wssList = ['proxy2.wynd.network:4444', 'proxy2.wynd.network:4650'];
        this.retryInterval = 20000;
        this.wssHost = this.wssList[Math.floor(Math.random() * this.wssList.length)];
    }
}

class Bot {
    constructor(config) {
        this.config = config;
    }

    async getProxyIP(proxy) {
        let agent;
        if (proxy.startsWith('socks://')) {
            agent = new SocksProxyAgent(proxy);
        } else if (proxy.startsWith('http://') || proxy.startsWith('https://')) {
            agent = new HttpsProxyAgent(proxy);
        } else {
            logger.warn(`Unsupported proxy format: ${proxy}`);
            return null;
        }

        try {
            const response = await axios.get(this.config.ipCheckURL, { httpsAgent: agent });
            logger.info(`Connected through proxy ${proxy}`);
            return response.data;
        } catch (error) {
            logger.warn(`Skipping proxy ${proxy} due to connection error: ${error.message}`);
            return null;
        }
    }

    async connectToProxy(proxy) {
        try {
            const proxyInfo = await this.getProxyIP(proxy);

            if (!proxyInfo) {
                logger.error(`Proxy ${proxy} is not reachable.`);
                return;
            }

            logger.info(`Formatted Proxy: ${proxy}`);

            let agent;
            if (proxy.startsWith('socks://')) {
                agent = new SocksProxyAgent(proxy);
            } else {
                agent = new HttpsProxyAgent(proxy);
            }

            const wsURL = `wss://${this.config.wssHost}`;
            const ws = new WebSocket(wsURL, {
                agent,
                headers: {
                    "Origin": configuration.Origin,
                    'User-Agent': configuration.UserAgent,
                },
            });

            ws.on('open', () => {
                logger.info(`Connected to ${proxy}`);
                logger.info(`Proxy IP Info: ${JSON.stringify(proxyInfo)}`);
                this.sendPing(ws, proxyInfo.ip);
            });

            ws.on('message', (message) => {
                const msg = JSON.parse(message);
                logger.info(`Received message: ${JSON.stringify(msg)}`);

                if (msg.action === 'AUTH') {
                    const authResponse = {
                        id: msg.id,
                        origin_action: 'AUTH',
                        result: {
                            browser_id: uuidv4(),
                            user_id: configuration.userId,
                            user_agent: configuration.UserAgent,
                            timestamp: Math.floor(Date.now() / 1000),
                            device_type: "extension",
                            version: "4.26.2",
                            extension_id: configuration.extension_id
                        },
                    };
                    ws.send(JSON.stringify(authResponse));
                    logger.info(`Sent auth response: ${JSON.stringify(authResponse)}`);
                } else if (msg.action === 'PONG') {
                    logger.info(`Received PONG: ${JSON.stringify(msg)}`);
                }
            });

            ws.on('close', (code, reason) => {
                logger.warn(`WebSocket closed with code: ${code}, reason: ${reason}`);
                setTimeout(() => this.connectToProxy(proxy), this.config.retryInterval);
            });

            ws.on('error', (error) => {
                logger.error(`WebSocket error on proxy ${proxy}: ${error.message}`);
                ws.terminate();
            });
        } catch (error) {
            logger.error(`Failed to connect with proxy ${proxy}: ${error.message}`);
        }
    }

    async connectDirectly() {
        try {
            const wsURL = `wss://${this.config.wssHost}`;
            const ws = new WebSocket(wsURL, {
                headers: {
                    "Origin": configuration.Origin,
                    'User-Agent': configuration.UserAgent,
                },
            });

            ws.on('open', () => {
                logger.info(`Connected directly without proxy`);
                this.sendPing(ws, 'Direct IP');
            });

            ws.on('message', (message) => {
                const msg = JSON.parse(message);
                logger.info(`Received message: ${JSON.stringify(msg)}`);

                if (msg.action === 'AUTH') {
                    const authResponse = {
                        id: msg.id,
                        origin_action: 'AUTH',
                        result: {
                            browser_id: uuidv4(),
                            user_id: configuration.userId,
                            user_agent: configuration.UserAgent,
                            timestamp: Math.floor(Date.now() / 1000),
                            device_type: "extension",
                            version: "4.26.2",
                            extension_id: configuration.extension_id
                        },
                    };
                    ws.send(JSON.stringify(authResponse));
                    logger.info(`Sent auth response: ${JSON.stringify(authResponse)}`);
                } else if (msg.action === 'PONG') {
                    logger.info(`Received PONG: ${JSON.stringify(msg)}`);
                }
            });

            ws.on('close', (code, reason) => {
                logger.warn(`WebSocket closed with code: ${code}, reason: ${reason}`);
                setTimeout(() => this.connectDirectly(), this.config.retryInterval);
            });

            ws.on('error', (error) => {
                logger.error(`WebSocket error: ${error.message}`);
                ws.terminate();
            });
        } catch (error) {
            logger.error(`Failed to connect directly: ${error.message}`);
        }
    }

    sendPing(ws, proxyIP) {
        setInterval(() => {
            const pingMessage = {
                id: uuidv4(),
                version: '1.0.0',
                action: 'PING',
                data: {},
            };
            ws.send(JSON.stringify(pingMessage));
            logger.info(`Sent ping - IP: ${proxyIP}, Message: ${JSON.stringify(pingMessage)}`);
        }, 26000);
    }
}

async function readLines(filename) {
    try {
        const data = await fs.promises.readFile(filename, 'utf-8');
        logger.info(`Loaded data from ${filename}`);
        return data.split('\n').filter(Boolean);
    } catch (error) {
        logger.error(`Failed to read ${filename}: ${error.message}`);
        return [];
    }
}

function CoderMark() {
    if (!CoderMarkPrinted) {
        console.log(`
╭━━━╮╱╱╱╱╱╱╱╱╱╱╱╱╱╭━━━┳╮
┃╭━━╯╱╱╱╱╱╱╱╱╱╱╱╱╱┃╭━━┫┃${cl.gr}
┃╰━━┳╮╭┳━┳━━┳━━┳━╮┃╰━━┫┃╭╮╱╭┳━╮╭━╮
┃╭━━┫┃┃┃╭┫╭╮┃╭╮┃╭╮┫╭━━┫┃┃┃╱┃┃╭╮┫╭╮╮${cl.br}
┃┃╱╱┃╰╯┃┃┃╰╯┃╰╯┃┃┃┃┃╱╱┃╰┫╰━╯┃┃┃┃┃┃┃
╰╯╱╱╰━━┻╯╰━╮┣━━┻╯╰┻╯╱╱╰━┻━╮╭┻╯╰┻╯╰╯${cl.rt}
╱╱╱╱╱╱╱╱╱╱╱┃┃╱╱╱╱╱╱╱╱╱╱╱╭━╯┃
╱╱╱╱╱╱╱╱╱╱╱╰╯╱╱╱╱╱╱╱╱╱╱╱╰━━╯
\n${cl.gb}${cl.gr}getGrass Minner Bot ${cl.rt}${cl.gb}v0.3${cl.rt}
        `);
        CoderMarkPrinted = true;
    }
}

async function main() {
    CoderMark();
    const config = new Config();
    const bot = new Bot(config);

    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    rl.question(`${cl.yl}Choose run option:\n\n${cl.rt}1. Run directly (without proxy)\n2. ${cl.gr}Run with proxy (proxy.txt)\n\n${cl.rt}Enter your choice: `, async (answer) => {
        if (answer === '2') {
            logger.info(`Please wait...\n`);
            const proxies = await readLines(configuration.proxyFile);
            if (proxies.length === 0) {
                logger.error('No proxies found. Exiting...');
                rl.close();
                return;
            }

            logger.info(`Loaded ${proxies.length} proxies`);
            const connectionPromises = proxies.map(proxy => bot.connectToProxy(proxy));
            await Promise.all(connectionPromises);
        } else {
            logger.info('Direct connection mode enabled.');
            await bot.connectDirectly();
        }
        rl.close();
    });
}

main().catch(logger.error);

