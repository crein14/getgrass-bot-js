// configuration.js

const configuration = {
    UserAgent: 'xxxxxxxx', // Replace with Your useragent
    userId: 'xxxxxxxx',  // Replace with Your User ID HERE
    proxyFile: 'proxy.txt', // your Path to Proxy.txt file
    // format proxies is => socks://username:pass@ip:port or http://username:pass@ip:port
    Origin: "chrome-extension://xxxxxxxx", // Replace with Your chrome-extension ID HERE
    extension_id: "xxxxxxxx", // Replace with Your chrome-extension ID HERE
};

module.exports = configuration;

