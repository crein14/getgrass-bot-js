// configuration
const config = {
    UserAgent : 'xxxxxxxxxxxxxx', // Replace with Your useragent
    userId: 'xxxxxxxxxxxxxx',  // Replace with Your User ID HERE
    proxyFile: 'proxy.txt' // your Path to Proxy.txt file
    // format proxies is => socks://username:pass@ip:port
};

module.exports = config;